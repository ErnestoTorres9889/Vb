﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        ListBox1 = New ListBox()
        Label4 = New Label()
        ListBox2 = New ListBox()
        Label5 = New Label()
        ListBox3 = New ListBox()
        Label6 = New Label()
        ListBox4 = New ListBox()
        ComboBox1 = New ComboBox()
        ComboBox2 = New ComboBox()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        TextBox1 = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Bisque
        Label1.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(88, 156)
        Label1.Name = "Label1"
        Label1.Size = New Size(42, 17)
        Label1.TabIndex = 0
        Label1.Text = "Items"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Bisque
        Label2.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(73, 196)
        Label2.Name = "Label2"
        Label2.Size = New Size(61, 17)
        Label2.TabIndex = 1
        Label2.Text = "Quantity"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(21, 305)
        Label3.Name = "Label3"
        Label3.Size = New Size(62, 17)
        Label3.TabIndex = 2
        Label3.Text = "Products"
        ' 
        ' ListBox1
        ' 
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Location = New Point(21, 336)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(184, 184)
        ListBox1.TabIndex = 3
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(211, 305)
        Label4.Name = "Label4"
        Label4.Size = New Size(37, 17)
        Label4.TabIndex = 4
        Label4.Text = "Price"
        ' 
        ' ListBox2
        ' 
        ListBox2.FormattingEnabled = True
        ListBox2.ItemHeight = 15
        ListBox2.Location = New Point(211, 336)
        ListBox2.Name = "ListBox2"
        ListBox2.Size = New Size(181, 184)
        ListBox2.TabIndex = 5
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(401, 304)
        Label5.Name = "Label5"
        Label5.Size = New Size(61, 17)
        Label5.TabIndex = 6
        Label5.Text = "Quantity"
        ' 
        ' ListBox3
        ' 
        ListBox3.FormattingEnabled = True
        ListBox3.ItemHeight = 15
        ListBox3.Location = New Point(398, 336)
        ListBox3.Name = "ListBox3"
        ListBox3.Size = New Size(184, 184)
        ListBox3.TabIndex = 7
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(588, 305)
        Label6.Name = "Label6"
        Label6.Size = New Size(37, 17)
        Label6.TabIndex = 8
        Label6.Text = "Total"
        ' 
        ' ListBox4
        ' 
        ListBox4.FormattingEnabled = True
        ListBox4.ItemHeight = 15
        ListBox4.Location = New Point(588, 336)
        ListBox4.Name = "ListBox4"
        ListBox4.Size = New Size(181, 184)
        ListBox4.TabIndex = 9
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(140, 153)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(172, 23)
        ComboBox1.TabIndex = 10
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(140, 193)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(173, 23)
        ComboBox2.TabIndex = 11
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImageLayout = ImageLayout.Center
        PictureBox1.BorderStyle = BorderStyle.FixedSingle
        PictureBox1.Image = My.Resources.Resources.Restaurant
        PictureBox1.Location = New Point(482, 112)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(228, 180)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 12
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(346, 143)
        Button1.Name = "Button1"
        Button1.Size = New Size(77, 40)
        Button1.TabIndex = 14
        Button1.Text = "Clear"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(346, 196)
        Button2.Name = "Button2"
        Button2.Size = New Size(77, 41)
        Button2.TabIndex = 15
        Button2.Text = "Post"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(579, 540)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(149, 23)
        TextBox1.TabIndex = 16
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(536, 541)
        Label7.Name = "Label7"
        Label7.Size = New Size(37, 17)
        Label7.TabIndex = 17
        Label7.Text = "Total"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.PeachPuff
        Label8.Font = New Font("Mistral", 48.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(245, 9)
        Label8.Name = "Label8"
        Label8.Size = New Size(269, 76)
        Label8.TabIndex = 18
        Label8.Text = "Restaurant"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.blobid15797791708461
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(786, 600)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(TextBox1)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(PictureBox1)
        Controls.Add(ComboBox2)
        Controls.Add(ComboBox1)
        Controls.Add(ListBox4)
        Controls.Add(Label6)
        Controls.Add(ListBox3)
        Controls.Add(Label5)
        Controls.Add(ListBox2)
        Controls.Add(Label4)
        Controls.Add(ListBox1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ListBox4 As ListBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label

End Class

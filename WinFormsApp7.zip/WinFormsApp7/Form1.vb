﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Fried Chicken - 40")
        ComboBox1.Items.Add("Spaghetti - 50")
        ComboBox1.Items.Add("French Fries - 30")
        ComboBox1.Items.Add("Mushroom Soup - 20")
        ComboBox1.Items.Add("Garlic Bread - 20")
        ComboBox1.Items.Add("Cheesecake - 40")
        ComboBox1.Items.Add("Cookies - 15")
        ComboBox1.Items.Add("Iced Tea - 15")
        ComboBox1.Items.Add("Cola - 10")
        ComboBox1.Items.Add("Water - 10")

        For i As Integer = 1 To 10
            ComboBox2.Items.Add(i.ToString())
        Next

        PictureBox1.Image = My.Resources.Restaurant
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Select Case ComboBox1.SelectedIndex
            Case 0
                PictureBox1.Image = My.Resources.Fried_Chicken
            Case 1
                PictureBox1.Image = My.Resources.Spaghetti
            Case 2
                PictureBox1.Image = My.Resources.French_Fries
            Case 3
                PictureBox1.Image = My.Resources.Mushroom_Soup
            Case 4
                PictureBox1.Image = My.Resources.Cheesecake
            Case 5
                PictureBox1.Image = My.Resources.Cookie
            Case 6
                PictureBox1.Image = My.Resources.Iced_Tea
            Case 7
                PictureBox1.Image = My.Resources.Coke
            Case 8
                PictureBox1.Image = My.Resources.Water


        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
      
        If ComboBox1.SelectedIndex = -1 Or ComboBox2.SelectedIndex = -1 Then
            MessageBox.Show("Please select both a product and quantity.")
            Return
        End If

        Try

            Dim selectedProduct As String = ComboBox1.SelectedItem.ToString()
            Dim productParts() As String = selectedProduct.Split("-"c)
            Dim productName As String = productParts(0).Trim()
            Dim price As Decimal = Convert.ToDecimal(productParts(1).Trim())


            Dim quantity As Integer = Convert.ToInt32(ComboBox2.SelectedItem)


            Dim totalPrice As Decimal = price * quantity


            ListBox1.Items.Add(productName)
            ListBox2.Items.Add(price.ToString("C"))
            ListBox3.Items.Add(quantity.ToString())
            ListBox4.Items.Add(totalPrice.ToString("C"))


            Dim finalTotal As Decimal = 0
            For Each item As String In ListBox4.Items
                Dim parsedPrice As Decimal

                If Decimal.TryParse(item, Globalization.NumberStyles.Currency, Nothing, parsedPrice) Then
                    finalTotal += parsedPrice
                Else
                    MessageBox.Show($"Unable to parse the total price: {item}")

                End If
            Next
            TextBox1.Text = finalTotal.ToString("C")
        Catch ex As Exception
            MessageBox.Show($"An error occurred: {ex.Message}")
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        TextBox1.Clear()

        PictureBox1.Image = My.Resources.Restaurant
    End Sub
End Class
